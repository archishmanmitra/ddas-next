
// Listen for extension installation
chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed and background service worker ready.');
    
    // Test notification to check if notifications work
    chrome.notifications.create('test-notification', {
      type: 'basic',
      iconUrl: 'icon-48.png',
      title: 'Test Notification',
      message: 'This is a test notification to ensure functionality.'
    }, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.error('Error creating test notification:', chrome.runtime.lastError);
      } else {
        console.log('Test notification displayed with ID:', notificationId);
      }
    });
  });
  
  // Detect duplicate downloads and show notification
  chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
    const filename = downloadItem.filename;
    const size = downloadItem.fileSize;
  
    if (size === -1) {
      console.warn('File size not available for:', downloadItem.url);
      return;
    }
  
    chrome.storage.local.get(['downloads'], (result) => {
      const downloads = result.downloads || [];
      const duplicate = downloads.find(d => d.filename === filename && d.size === size);
  
      if (duplicate) {
        chrome.notifications.create('duplicate-download', {
          type: 'basic',
          title: 'Duplicate Download Detected',
          message: `The file "${filename}" has already been downloaded.`,
          iconUrl: 'icon-48.png'
        }, (notificationId) => {
          if (chrome.runtime.lastError) {
            console.error('Error creating notification:', chrome.runtime.lastError);
          } else {
            console.log('Duplicate download notification displayed with ID:', notificationId);
          }
        });
  
        chrome.downloads.cancel(downloadItem.id, () => {
          console.log('Duplicate download canceled:', filename);
        });
      } else {
        downloads.push({ filename, size, timestamp: Date.now() });
        chrome.storage.local.set({ downloads }, () => {
          console.log('New download saved:', filename);
        });
      }
    });
  });
